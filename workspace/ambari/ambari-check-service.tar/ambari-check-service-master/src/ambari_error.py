class AmbariError(Exception):
  pass
